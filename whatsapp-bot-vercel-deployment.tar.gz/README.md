# Queen Anita V4 WhatsApp Bot

A powerful Multi-Device WhatsApp Bot featuring various utilities and media tools, deployed on Vercel.

## Features

- Multi-device support
- Various utility commands
- Media processing capabilities
- Group management features
- Auto-response features

## Configuration

The bot is configured with the following settings:

- **Owner Number**: 923051625609
- **Prefix**: .
- **Bot Name**: 𝐐𝐔𝐄𝐄𝐍_𝐀𝐍𝐈𝐓𝐀-𝐕𝟒
- **Owner Name**: David Cyril

## Deployment

This bot is deployed on Vercel for free long-term hosting.

## Usage

Send commands with the prefix `.` to interact with the bot.

## Author

Created by David Cyril

