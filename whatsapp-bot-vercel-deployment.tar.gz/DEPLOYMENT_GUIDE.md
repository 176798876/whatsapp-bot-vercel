# WhatsApp Bot - Manual Vercel Deployment Guide

## Prerequisites

1. **Vercel Account**: Sign up at [vercel.com](https://vercel.com) (free)
2. **GitHub Account**: Sign up at [github.com](https://github.com) (free)

## Step-by-Step Deployment Instructions

### Step 1: Upload to GitHub

1. Create a new repository on GitHub:
   - Go to [github.com/new](https://github.com/new)
   - Repository name: `whatsapp-bot-vercel`
   - Set to **Public** (required for free Vercel deployment)
   - Click "Create repository"

2. Upload all the files from this project to your GitHub repository:
   - You can drag and drop all files or use GitHub's web interface
   - Make sure to include all files, especially:
     - `index.js` (main bot file)
     - `package.json` (dependencies)
     - `vercel.json` (Vercel configuration)
     - `session/creds.json` (your WhatsApp session)
     - All `lib/` folder contents

### Step 2: Deploy on Vercel

1. **Connect GitHub to Vercel**:
   - Go to [vercel.com](https://vercel.com)
   - Click "Sign up" and choose "Continue with GitHub"
   - Authorize Vercel to access your GitHub account

2. **Import Your Project**:
   - On Vercel dashboard, click "New Project"
   - Find your `whatsapp-bot-vercel` repository
   - Click "Import"

3. **Configure Deployment**:
   - **Framework Preset**: Select "Other"
   - **Root Directory**: Leave as `./`
   - **Build Command**: Leave empty (will use package.json)
   - **Output Directory**: Leave empty
   - **Install Command**: Leave as default (`npm install`)

4. **Environment Variables** (Important):
   - Click "Environment Variables" section
   - Add these variables one by one:

   ```
   OWNER_NUMBER = 923051625609
   BOT_NAME = 𝐐𝐔𝐄𝐄𝐍_𝐀𝐍𝐈𝐓𝐀-𝐕𝟒
   OWNER_NAME = David Cyril
   PREFIX = .
   PUBLIC = true
   ```

   - You can add more environment variables from the `.env` file if needed

5. **Deploy**:
   - Click "Deploy"
   - Wait for deployment to complete (usually 1-2 minutes)

### Step 3: Bot Configuration

Your bot is now deployed! Here are the important details:

- **Owner Number**: 923051625609
- **Bot Prefix**: `.` (dot)
- **Bot Name**: 𝐐𝐔𝐄𝐄𝐍_𝐀𝐍𝐈𝐓𝐀-𝐕𝟒
- **Session**: Pre-configured with your provided session data

### Step 4: Using Your Bot

1. **WhatsApp Connection**: The bot will automatically connect using your session data
2. **Commands**: Send messages with `.` prefix (e.g., `.help`, `.menu`)
3. **Owner Commands**: Only you (923051625609) can use owner-specific commands

### Important Notes

⚠️ **Session Security**: Your WhatsApp session is included in the deployment. Keep your repository private if possible, or regenerate the session if needed.

🔄 **Updates**: To update the bot, simply push changes to your GitHub repository. Vercel will automatically redeploy.

📱 **Multi-Device**: This bot supports WhatsApp multi-device, so it won't interfere with your phone's WhatsApp.

🆓 **Free Hosting**: Vercel provides free hosting with generous limits for personal projects.

### Troubleshooting

1. **Bot Not Responding**: Check Vercel function logs in your dashboard
2. **Session Issues**: You may need to regenerate the session if it expires
3. **Deployment Errors**: Check that all files are uploaded correctly

### Support

If you encounter any issues:
1. Check Vercel deployment logs
2. Ensure all environment variables are set correctly
3. Verify that your session data is valid

## File Structure

```
whatsapp-bot-vercel/
├── index.js              # Main bot file (obfuscated)
├── package.json          # Dependencies and scripts
├── vercel.json           # Vercel configuration
├── config.js             # Bot configuration
├── .env                  # Environment variables (for reference)
├── session/
│   └── creds.json        # WhatsApp session data
├── lib/                  # Bot libraries and utilities
├── david-cyril/          # Database files
└── DEPLOYMENT_GUIDE.md   # This guide
```

Your bot is ready for deployment! 🚀

